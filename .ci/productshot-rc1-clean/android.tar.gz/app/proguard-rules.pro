# ProductShot has no reflection-based app model. Android entry points referenced from
# the manifest are retained by the Android/R8 toolchain. Keep useful source context
# in crash diagnostics while still allowing code shrinking/obfuscation.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
