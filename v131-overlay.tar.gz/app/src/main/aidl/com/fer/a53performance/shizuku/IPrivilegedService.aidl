package com.fer.a53performance.shizuku;

interface IPrivilegedService {
    void destroy() = 16777114;
    String exec(String command) = 1;
    String[] scanMedia(in String[] roots, int maxFiles, int maxResults) = 2;
    long deletePaths(in String[] paths) = 3;
    long clearExternalCaches() = 4;
    String[] deletePathsDetailed(in String[] paths) = 5;
}
