package com.fer.a53performance.shizuku

import android.content.Context
import android.system.Os
import androidx.annotation.Keep
import java.io.File
import java.util.PriorityQueue
import java.util.concurrent.TimeUnit

class PrivilegedUserService : IPrivilegedService.Stub {
    constructor() : super()

    @Keep
    constructor(context: Context) : super()

    override fun destroy() {
        System.exit(0)
    }

    override fun exec(command: String): String {
        if (command.length > 8_000) return "ERR: command too long"
        return runCatching {
            val process = ProcessBuilder("/system/bin/sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val finished = process.waitFor(90, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                return@runCatching "ERR: timeout"
            }
            val output = process.inputStream.bufferedReader().use { it.readText().take(64_000) }
            "exit=${process.exitValue()}\n$output".trim()
        }.getOrElse { "ERR: ${it.javaClass.simpleName}: ${it.message ?: "sin detalle"}" }
    }

    override fun scanMedia(roots: Array<out String>?, maxFiles: Int, maxResults: Int): Array<String> {
        if (roots == null || maxFiles <= 0 || maxResults <= 0) return emptyArray()
        val extensions = setOf(
            "jpg", "jpeg", "png", "webp", "heic", "heif", "bmp", "avif", "gif",
            "mp4", "mkv", "webm", "3gp", "mov", "avi", "m4v",
            "opus", "ogg", "mp3", "m4a", "aac", "wav", "amr",
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "zip", "rar", "7z"
        )
        data class Record(val size: Long, val path: String)
        val heap = PriorityQueue<Record>(compareBy<Record> { it.size }.thenBy { it.path })
        val stack = ArrayDeque<File>()
        roots.map(::File).filter { it.exists() }.forEach(stack::add)
        var seen = 0
        val limitFiles = maxFiles.coerceIn(1, 180_000)
        val limitResults = maxResults.coerceIn(1, 2_000)

        while (stack.isNotEmpty() && seen < limitFiles) {
            val current = stack.removeLast()
            if (current.isDirectory) {
                val children = runCatching { current.listFiles() }.getOrNull() ?: continue
                for (child in children) {
                    if (seen >= limitFiles) break
                    seen++
                    if (child.isDirectory) stack.add(child)
                    else {
                        val ext = child.extension.lowercase()
                        if (ext !in extensions) continue
                        val size = runCatching { child.length() }.getOrDefault(0L)
                        if (size <= 0L) continue
                        val rec = Record(size, child.absolutePath)
                        if (heap.size < limitResults) heap.add(rec)
                        else if (size > heap.peek().size) {
                            heap.poll(); heap.add(rec)
                        }
                    }
                }
            }
        }
        return heap.toList().sortedByDescending { it.size }.map { "${it.size}\t${it.path}" }.toTypedArray()
    }

    override fun deletePaths(paths: Array<out String>?): Long {
        return deletePathsDetailed(paths).sumOf { row ->
            val parts = row.split('\t', limit = 3)
            if (parts.getOrNull(1) == "OK") parts.getOrNull(2)?.toLongOrNull() ?: 0L else 0L
        }
    }

    override fun deletePathsDetailed(paths: Array<out String>?): Array<String> {
        if (paths == null) return emptyArray()
        val out = ArrayList<String>()
        paths.take(500).forEachIndexed { index, raw ->
            val path = runCatching { File(raw).canonicalPath }.getOrNull()
            if (path == null || !isSafeSharedPath(path)) {
                out += "$index\tFAIL\t0"
                return@forEachIndexed
            }
            val file = File(path)
            if (!file.exists()) {
                out += "$index\tOK\t0"
                return@forEachIndexed
            }
            if (!file.isFile) {
                out += "$index\tFAIL\t0"
                return@forEachIndexed
            }
            val size = runCatching { file.length() }.getOrDefault(0L)
            val deleted = deleteFileHard(file)
            out += "$index\t${if (deleted) "OK" else "FAIL"}\t${if (deleted) size else 0L}"
        }
        return out.toTypedArray()
    }

    private fun deleteFileHard(file: File): Boolean {
        if (!file.exists()) return true
        if (runCatching { file.delete() }.getOrDefault(false) && !file.exists()) return true
        runCatching {
            val process = ProcessBuilder("/system/bin/rm", "-f", file.absolutePath)
                .redirectErrorStream(true)
                .start()
            if (!process.waitFor(15, TimeUnit.SECONDS)) process.destroyForcibly()
        }
        return !file.exists()
    }

    override fun clearExternalCaches(): Long {
        val roots = listOf(File("/storage/emulated/0/Android/data"), File("/sdcard/Android/data"))
            .filter { it.exists() && it.isDirectory }
            .distinctBy { runCatching { it.canonicalPath }.getOrDefault(it.absolutePath) }
        var freed = 0L
        val visited = HashSet<String>()
        for (root in roots) {
            val packages = runCatching { root.listFiles() }.getOrNull() ?: continue
            for (pkg in packages) {
                if (!pkg.isDirectory) continue
                for (name in listOf("cache", "code_cache")) {
                    val cache = File(pkg, name)
                    val canonical = runCatching { cache.canonicalPath }.getOrNull() ?: continue
                    if (!visited.add(canonical) || !cache.exists() || !cache.isDirectory) continue
                    val children = runCatching { cache.listFiles() }.getOrNull() ?: continue
                    for (child in children) freed += deleteRecursivelySafe(child)
                }
            }
        }
        return freed
    }

    private fun deleteRecursivelySafe(file: File): Long {
        val canonical = runCatching { file.canonicalPath }.getOrNull() ?: return 0L
        if (!isSafeSharedPath(canonical)) return 0L
        if (file.isFile) {
            val size = runCatching { file.length() }.getOrDefault(0L)
            return if (runCatching { file.delete() }.getOrDefault(false)) size else 0L
        }
        var freed = 0L
        runCatching { file.listFiles() }.getOrNull()?.forEach { freed += deleteRecursivelySafe(it) }
        runCatching { file.delete() }
        return freed
    }

    private fun isSafeSharedPath(path: String): Boolean {
        return path.startsWith("/storage/emulated/0/") || path.startsWith("/sdcard/")
    }

    fun identity(): String = "uid=${Os.getuid()} pid=${Os.getpid()}"
}
