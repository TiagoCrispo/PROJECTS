package com.fer.a53performance

import android.app.Application
import android.content.pm.ApplicationInfo
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fer.a53performance.data.AppPreferences
import com.fer.a53performance.data.CleanableFile
import com.fer.a53performance.data.DeviceStatsRepository
import com.fer.a53performance.model.AppMode
import com.fer.a53performance.model.AppUiState
import com.fer.a53performance.model.RecentDocument
import com.fer.a53performance.service.ModeController
import com.fer.a53performance.shizuku.PrivilegedDeleteResult
import com.fer.a53performance.shizuku.ShizukuController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    private val prefs = AppPreferences(application)
    private val statsRepo = DeviceStatsRepository(application)
    private val modeController = ModeController(application)
    private val shizukuController = ShizukuController(application)
    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()
    private var timerJob: Job? = null

    private val protectedPackages = setOf(
        "com.openai.chatgpt",
        "com.brave.browser",
        "com.microsoft.office.word",
        "com.microsoft.office.officehubrow",
        "com.spotify.music",
        "com.whatsapp",
        "com.whatsapp.w4b",
        BuildConfig.APPLICATION_ID,
        "moe.shizuku.privileged.api"
    )

    init {
        refreshStats()
        viewModelScope.launch { prefs.activeMode.collectLatest { _uiState.value = _uiState.value.copy(activeMode = if (it == AppMode.CLASS) AppMode.BALANCED else it) } }
        viewModelScope.launch { prefs.quickNote.collectLatest { _uiState.value = _uiState.value.copy(quickNote = it) } }
        viewModelScope.launch { prefs.recentDocuments.collectLatest { _uiState.value = _uiState.value.copy(recentDocuments = it) } }
        viewModelScope.launch { prefs.advancedMode.collectLatest { _uiState.value = _uiState.value.copy(advancedMode = it) } }
        viewModelScope.launch { shizukuController.state.collectLatest { _uiState.value = _uiState.value.copy(shizuku = it) } }
        viewModelScope.launch {
            while (true) {
                refreshStats()
                shizukuController.refresh()
                delay(3_000)
            }
        }
    }

    fun refreshStats() {
        _uiState.value = _uiState.value.copy(stats = statsRepo.read())
    }

    fun activateMode(mode: AppMode) {
        viewModelScope.launch {
            val previous = _uiState.value.activeMode
            prefs.setActiveMode(mode)
            val local = modeController.applyLocal(mode)
            _uiState.value = _uiState.value.copy(
                activeMode = mode,
                dndEnabledByApp = false,
                lastModeMessage = local.message
            )

            if (_uiState.value.shizuku.connected) {
                if (previous == AppMode.BATTERY && mode != AppMode.BATTERY) {
                    shizukuController.restoreBatteryRestrictions()
                }

                val baseOut = shizukuController.exec(modeController.privilegedCommand(mode))
                var message = modeController.privilegedSummary(mode, baseOut)

                when (mode) {
                    AppMode.GAMING -> {
                        val games = installedGamePackages()
                        val gameOut = shizukuController.applyGameModes(games)
                        val applied = gameOut.lineSequence().count { it.contains("GAME_OK|") }
                        message += if (games.isEmpty()) {
                            " No detecté juegos Android marcados por el sistema."
                        } else {
                            " Game Mode rendimiento: $applied/${games.size} juegos aceptaron la orden."
                        }
                    }
                    AppMode.BATTERY -> {
                        val userApps = installedThirdPartyPackages()
                        val installedProtected = protectedPackages.filter { isInstalled(it) }
                        val protectedUids = installedProtected.mapNotNull { packageUid(it) }
                        val batteryOut = shizukuController.applyBatteryRestrictions(userApps, installedProtected, protectedUids)
                        val restricted = Regex("(\\d+) apps secundarias").find(batteryOut)?.groupValues?.getOrNull(1)
                        message += " Ahorro extremo activo${restricted?.let { ": $it apps secundarias restringidas" } ?: ""}. ChatGPT, Brave, Word/Microsoft 365, Spotify y WhatsApp quedan protegidas."
                    }
                    else -> Unit
                }
                _uiState.value = _uiState.value.copy(lastModeMessage = message)
            }

            delay(900)
            refreshStats()
        }
    }

    fun requestShizuku() = shizukuController.requestPermissionAndBind()
    suspend fun deepCleanCaches(): String = shizukuController.deepCleanCaches()
    suspend fun clearAppCache(packageName: String): String = shizukuController.clearAppCache(packageName)
    suspend fun clearAppCaches(packages: Collection<String>): String = shizukuController.clearAppCaches(packages)
    suspend fun grantUsageStatsWithShizuku(): Boolean = shizukuController.grantUsageStats()
    suspend fun scanProtectedMedia(): List<CleanableFile> = shizukuController.scanProtectedMedia()
    suspend fun deletePrivileged(paths: Collection<String>): PrivilegedDeleteResult = shizukuController.deletePrivilegedDetailed(paths)

    fun canWriteSettings(): Boolean = modeController.canWriteSettings()

    @Suppress("DEPRECATION")
    private fun installedThirdPartyPackages(): List<String> = app.packageManager.getInstalledApplications(0)
        .asSequence()
        .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
        .filter { it.packageName != BuildConfig.APPLICATION_ID }
        .map { it.packageName }
        .distinct()
        .toList()

    @Suppress("DEPRECATION")
    private fun installedGamePackages(): List<String> = app.packageManager.getInstalledApplications(0)
        .asSequence()
        .filter { it.enabled && it.category == ApplicationInfo.CATEGORY_GAME }
        .map { it.packageName }
        .distinct()
        .toList()

    private fun isInstalled(packageName: String): Boolean = runCatching {
        app.packageManager.getApplicationInfo(packageName, 0)
        true
    }.getOrDefault(false)

    private fun packageUid(packageName: String): Int? = runCatching {
        app.packageManager.getApplicationInfo(packageName, 0).uid
    }.getOrNull()

    fun setFocusMinutes(minutes: Int) {
        _uiState.value = _uiState.value.copy(focusMinutes = minutes.coerceIn(10, 180))
    }

    fun startFocus() {
        timerJob?.cancel()
        val total = _uiState.value.focusMinutes * 60
        _uiState.value = _uiState.value.copy(focusSecondsLeft = total, focusRunning = true)
        timerJob = viewModelScope.launch {
            var remaining = total
            while (remaining > 0) {
                delay(1_000)
                remaining--
                _uiState.value = _uiState.value.copy(focusSecondsLeft = remaining)
            }
            _uiState.value = _uiState.value.copy(focusRunning = false)
        }
    }

    fun stopFocus() {
        timerJob?.cancel()
        _uiState.value = _uiState.value.copy(focusRunning = false, focusSecondsLeft = 0)
    }

    fun updateQuickNote(value: String) {
        _uiState.value = _uiState.value.copy(quickNote = value)
        viewModelScope.launch { prefs.setQuickNote(value) }
    }

    fun addRecentDocument(uri: Uri, name: String) {
        viewModelScope.launch { prefs.addRecentDocument(RecentDocument(uri, name)) }
    }

    fun setAdvancedMode(enabled: Boolean) {
        viewModelScope.launch { prefs.setAdvancedMode(enabled) }
    }
}
